import React, { Component } from 'react';
import "bootstrap/dist/css/bootstrap.min.css";
import './App.css';
import {BrowserRouter as Router, Switch, Route, Link} from 'react-router-dom';
import Login from './components/login.component';
import Register from './components/register.component';
import User from './components/user.component';
import Home from './components/home.component';

import AuthService from './services/auth-service'

class App extends Component{
  constructor(props){
  super(props);
  this.logOut = this.logOut.bind(this);
  this.state={
    currentUser:undefined
  }

}
logOut() {
  AuthService.logout();
}
componentDidMount(){
  const user=AuthService.getCurrentUser();
  console.log(user);
  if(user){
    this.setState({
      currentUser:user
    })
  }
}
  render(){
    const { currentUser} = this.state;
  return (
    <Router>
        <div>          
          <nav className="navbar navbar-expand navbar-dark bg-dark">
            <div className="container">
                      
                <Link to={"/"} className="navbar-brand">
                  Delhi
                </Link>
                <div className="navbar-nav mr-auto">
                  <li className="nav-item">
                    <Link to={"/"} className="nav-link">
                      Home
                    </Link>
                  </li>
                </div>
                {currentUser ? (
                    <div className="navbar-nav ml-auto">
                      <li className="nav-item">
                        <Link to={"/user"} className="nav-link">
                        Profile
                        </Link>
                      </li>
                      <li className="nav-item">
                        <a href="/login" className="nav-link" onClick={this.logOut}>
                          LogOut
                        </a>
                      </li>
                    </div>
                  ):(            
                  <div className="navbar-nav ml-auto">
                    <li className="nav-item">
                      <Link to={"/login"} className="nav-link">
                        Login
                      </Link>
                    </li>
                  </div> )}
                </div>
                 
          </nav>

          <div className="container mt-3">
            <Switch>
              <Route exact path={["/", "/home"]} component={Home} />
              <Route exact path="/login" component={Login} />
              <Route exact path="/register" component={Register} />              
              <Route path="/user" component={User} />            
            </Switch>
          </div>
        </div>
      </Router>
  );
}
}

export default App;
