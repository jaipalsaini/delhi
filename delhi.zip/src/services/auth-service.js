import axios from "axios";

const API_URL = "http://165.22.211.35/api/auth/";

class AuthService {
  // user login method
  login(email, password) {
    return axios
      .post(API_URL + "login", {
        email,
        password
      })
      .then(response => {    
        if (response.data.data.token) {
            console.log(response.data);
          localStorage.setItem("user", JSON.stringify(response.data));
        }
        return response.data;
      });
  }
  //logout method
  logout() {
    localStorage.removeItem("user");
  }

  // user registration method
  userRegister(email, password, name,user_type, mobile, password_confirmation) {
     
    return axios.post(API_URL + "register", {
        email,
        password,
        name,
        user_type,
        mobile,
        password_confirmation
    });
    
  }
  // get current user 
  getCurrentUser() {
    return JSON.parse(localStorage.getItem('user'));;
  }
}
export default new AuthService();
