export default function authHeader() {
    const user = JSON.parse(localStorage.getItem('user'));
   console.log(user.data.token)
    if (user && user.data.token) {
      // for Node.js Express back-end
      return { Authorization: 'Bearer ' + user.data.token };
    } else {
      return {};
    }
    
  }
  