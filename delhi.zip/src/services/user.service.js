import axios from 'axios';
import authHeader from './auth-header';

const API_URL = "http://165.22.211.35/api/auth/";

class UserService {

    getUserDetails() {
        return axios.get(API_URL + 'UserDetails', { headers: authHeader() });
      }


}

export default new UserService();