import React, { Component } from "react";
import Form from "react-validation/build/form";
import Input from "react-validation/build/input";
import { isEmail,isMobilePhone} from "validator";

import AuthService from "../services/auth-service"

//constant block 
const required = value => {
    if (!value) {
      return (
        <div className="alert alert-danger" role="alert">
          This field is required!
        </div>
      );
    }
  };
  
  const email = value => {
    if (!isEmail(value)) {              
      return (     
        <div className="alert alert-danger" role="alert">
          This is not a valid email.
        </div>
      );
    }
  };
  
  const vusername = value => {
    if (value.length < 3 || value.length > 20) {
      return (
        <div className="alert alert-danger" role="alert">
          The username must be between 3 and 20 characters.
        </div>
      );
    }
  };
  
  const vpassword = value => {
    if (value.length < 6 || value.length > 40) {
      return (
        <div className="alert alert-danger" role="alert">
          The password must be between 6 and 40 characters.
        </div>
      );
    }
  };
  
  const mobile = value => {
    if (value.length !==10 || !isMobilePhone(value)) {
      return (
        <div className="alert alert-danger" role="alert">
         Enter a valid mobile number
        </div>
      );
    }
  };
  //------------ end constant block
export default class Register extends Component{
    constructor(props) {
        super(props);
        this.handleRegister = this.handleRegister.bind(this);
        this.onChangeUsername = this.onChangeUsername.bind(this);
        this.onChangeEmail = this.onChangeEmail.bind(this);
        this.onChangePassword = this.onChangePassword.bind(this);
        this.onChangeMobile=this.onChangeMobile.bind(this);
        this.onChangeConfirmPassword=this.onChangeConfirmPassword.bind(this);
        this.inputRer=React.createRef();
        this.state = {
          username: "",
          email: "",
          password: "",
          mobile: "",
          confirmPassword:"",
          userType:"admin",
          successful: false,
          message: ""
        };
      }
    
//input handle method

      onChangeUsername(e) {
        this.setState({
          username: e.target.value
        });
      }
    
      onChangeEmail(e) {
        this.setState({
          email: e.target.value
        });
      }
    
      onChangePassword(e) {
        this.setState({
          password: e.target.value
        });
      }
      onChangeMobile(e){
        this.setState({
            mobile:e.target.value
        })
      }
      onChangeConfirmPassword(e){
          this.setState({
              confirmPassword:e.target.value
            })
      }
    //======== end input handle function

      handleRegister(e) {
        e.preventDefault();    
        this.setState({
          message: "",
          successful: false
        });    
        this.form.validateAll();
        AuthService.userRegister(           
            this.state.email,
            this.state.password,
            this.state.username,
            this.state.userType,
            this.state.mobile,
            this.state.confirmPassword
        ).then(
            response=>{
                console.log(response.data);
                this.setState({
                    message:response.data.message,
                    successful:true
                })
            }
        );  
        
      }
    
 render(){
     return(
        <React.StrictMode>
        <div className="col-md-12 align-self-center">
        <div className="card card-container form-padding">
        
          <Form name="register"
            onSubmit={this.handleRegister}
            ref={c => {
              this.form = c;
            }}
          >
            {!this.state.successful && (
              <div>
                <div className="form-group">
                  <label htmlFor="username">Username</label>
                  <Input
                    type="text"
                    className="form-control"
                    name="username"
                    value={this.state.username}
                    onChange={this.onChangeUsername}
                    validations={[required, vusername]}
                  />
                </div>

                <div className="form-group">
                  <label htmlFor="email">Email</label>
                  <Input
                  ref={this.inputRer}
                    type="text"
                    className="form-control"
                    name="email"
                    value={this.state.email}
                    onChange={this.onChangeEmail}
                    validations={[required, email]}
                  />
                </div>
                <div className="form-group">
                  <label htmlFor="mobile">Mobile Number</label>
                  <Input
                    type="text"
                    className="form-control"
                    name="mobile"
                    value={this.state.mobile}
                    onChange={this.onChangeMobile}  
                    validations={[required, mobile]}                 
                  />
                </div>

                <div className="form-group">
                  <label htmlFor="password">Password</label>
                  <Input
                    type="password"
                    className="form-control"
                    name="password"
                    value={this.state.password}
                    onChange={this.onChangePassword}
                    validations={[required, vpassword]}
                  />
                </div>
                 
                <div className="form-group">
                  <label htmlFor="confirmPassword">Confirm Password</label>
                  <Input
                    type="password"
                    className="form-control"
                    name="confirmPassword"
                    value={this.state.confirmPassword}
                    onChange={this.onChangeConfirmPassword}
                    validations={[required]}
                  />
                </div>
                <div className="form-group">
                  <button className="btn btn-primary btn-block">Sign Up</button>
                </div>
              </div>
            )}

            {this.state.message && (
              <div className="form-group">
                <div
                  className={
                    this.state.successful
                      ? "alert alert-success"
                      : "alert alert-danger"
                  }
                  role="alert"
                >
                  {this.state.message}
                  
                </div>
              </div>
            )}
            
          </Form>
        </div>
      </div>
      </React.StrictMode>
     );
 }
}