import React, { Component } from "react";

import UserService from '../services/user.service'
export default class User extends Component{
    constructor(props) {
        super(props);
    
        this.state = {
          content: ""
        };
      }
 
 componentDidMount(){

     UserService.getUserDetails().then(
        response => {
            console.log(response.data);
          this.setState({
            content: response.data
          });
        },
        error => {
            this.setState({
              content:
                (error.response && error.response.data) ||
                error.message ||
                error.toString()
            });
          }
        )
 }
    render(){
        return(
            <div>
                {this.state.content.email}
           </div>
        );
    }
}