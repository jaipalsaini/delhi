import React, { Component } from "react";

import AuthService from '../services/auth-service'
export default class Home extends Component{
    constructor(props){
            super(props);
            this.state={
                currentUser:AuthService.getCurrentUser(),
                message:''
            }

          
    }
    componentDidMount(){
         const user =AuthService.getCurrentUser()
        if(user.data.token){
            this.setState({message:'Login Successful'})
          }
    }
    render(){
        const { currentUser }=this.state;
        return(
            <div className="container">
                <header className="jumbotron">
                    <h3>
                      
                        <strong>{this.state.message}</strong>
                    </h3>
                </header>
           </div>
        );
    }
}