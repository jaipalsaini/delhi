import React, { Component } from "react";
import Form from "react-validation/build/form";
import Input from "react-validation/build/input";

import AuthService from '../services/auth-service'
//constant block
const required = value => {
    if (!value) {
      return (
        <div className="alert alert-danger" role="alert">
          This field is required!
        </div>
      );
    }
  };
//end contant block

export default class Login extends Component{
    constructor(props) {
        super(props);
        this.handleLogin = this.handleLogin.bind(this);
        this.onChangeUsername = this.onChangeUsername.bind(this);
        this.onChangePassword = this.onChangePassword.bind(this);
    
        this.state = {
          email: "",
          password: "",
          loading: false,
          message: ""
        };
      }
    //input handle method 
      onChangeUsername(e) {
        this.setState({
          email: e.target.value
        });
      }    
      onChangePassword(e) {
        this.setState({
          password: e.target.value
        });
      }
    //end user handle method 

    //login method
      handleLogin(e) {
        e.preventDefault();
    
        this.setState({
          message: "",
          loading: true
        });   
        
        AuthService.login(this.state.email, this.state.password).then(
            () => {
            //console.log("login successful");
             this.props.history.push("/");
             window.location.reload();
            },
            error => {
                const resMessage =
                  (error.response &&
                    error.response.data &&
                    error.response.data.message) ||
                  error.message ||
                  error.toString();
      
                this.setState({
                  loading: false,
                  message: resMessage
                });
              }
            );   
        }

render(){
    return(
        <React.StrictMode>
        <div className="col-md-12">            
            <div className="card card-container form-padding">        
            <Form
                onSubmit={this.handleLogin}             
              
            >
                <div className="form-group">
                <label htmlFor="username">Username</label>
                <Input
                    type="text"
                    className="form-control"
                    name="username"
                    value={this.state.email}
                    onChange={this.onChangeUsername}
                    validations={[required]}
                    placeholder="Enter E-mail"
                />
                </div>

                <div className="form-group">
                <label htmlFor="password">Password</label>
                <Input
                    type="password"
                    className="form-control"
                    name="password"
                    value={this.state.password}
                    onChange={this.onChangePassword}
                    validations={[required]}
                    placeholder="Enter password"
                />
                </div>

                <div className="form-group">
                <button
                    className="btn btn-primary btn-block"
                    disabled={this.state.loading}
                >
                    {this.state.loading && (
                    <span className="spinner-border spinner-border-sm"></span>
                    )}
                    <span>Login</span>
                </button>
                </div>

                {this.state.message && (
                <div className="form-group">
                    <div className="alert alert-danger" role="alert">
                    {this.state.message}
                    </div>
                </div>
                )}              
            </Form>
            <a href="/register" className="btn btn-outline-primary">Register Now ?</a>
            </div>           
      </div>
      </React.StrictMode>
    );
}


}